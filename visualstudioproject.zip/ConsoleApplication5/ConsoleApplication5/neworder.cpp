//Anurag Misra 12144
//Made as a part of Computer Graphics Course

#include <GLTools.h>
#include <GLShaderManager.h>
#include <GLFrustum.h>
#include <GLBatch.h>
#include <GLMatrixStack.h>
#include <GLGeometryTransform.h>
#include <StopWatch.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

/* GLM */
// #define GLM_MESSAGES
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <shader_utils.h>

#ifdef __APPLE__
#include <glut/glut.h>
#else
#include <GL/glut.h>
#endif

#define NUM_SPHERES 17
GLFrame spheres[NUM_SPHERES];
GLFrame cyl[24][4];

GLFrame cu[12][12];


int m[12][12] = { { 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1 }, { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 }, { 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
{ 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1 }, { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1 }, { 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1 },
{ 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1 }, { 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1 }, { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };


GLShaderManager		shaderManager;			// Shader Manager
GLMatrixStack		modelViewMatrix;		// Modelview Matrix
GLMatrixStack		projectionMatrix;		// Projection Matrix
GLFrustum			viewFrustum;			// View Frustum
GLGeometryTransform	transformPipeline;		// Geometry Transform Pipeline
GLFrame				cameraFrame;			// Camera frame
GLTriangleBatch		torusBatch;
GLTriangleBatch		sphereBatch;
GLTriangleBatch		diskBatch;
GLBatch cubeBatch;

GLBatch				floorBatch;
GLBatch				floorBatch1;
GLBatch				floorBatch2;
GLBatch				floorBatch3;

GLTriangleBatch		cylBatch;
GLBatch             ceilingBatch;
GLBatch             leftWallBatch;
GLBatch             rightWallBatch;

GLuint				uiTextures[6];
/*
class Mesh {
private:
	GLuint vbo_vertices, vbo_normals, ibo_elements;
public:
	std::vector<glm::vec4> vertices;
	std::vector<glm::vec3> normals;
	std::vector<GLushort> elements;
	glm::mat4 object2world;

	Mesh() : vbo_vertices(0), vbo_normals(0), ibo_elements(0), object2world(glm::mat4(1)) {}
	~Mesh() {
		if (vbo_vertices != 0)
			glDeleteBuffers(1, &vbo_vertices);
		if (vbo_normals != 0)
			glDeleteBuffers(1, &vbo_normals);
		if (ibo_elements != 0)
			glDeleteBuffers(1, &ibo_elements);
	}

}

void ObjectOrder()
{

	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	// Read our .obj file
	std::vector<glm::vec3> vertices;
	std::vector<glm::vec2> uvs;
	std::vector<glm::vec3> normals; // Won't be used at the moment.
	bool res = loadOBJ("ninga1.obj", vertices, uvs, normals);

	GLuint vertexbuffer;
	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), &vertices[0], GL_STATIC_DRAW);

	GLuint uvbuffer;
	glGenBuffers(1, &uvbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
	glBufferData(GL_ARRAY_BUFFER, uvs.size() * sizeof(glm::vec2), &uvs[0], GL_STATIC_DRAW);




}

*/
void WorldOrder2()
{
	static GLfloat vWhite[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	static GLfloat vLightPos[] = { -10.0f, 30.0f, -80.0f, 1.0f };
	static GLfloat vLightPos1[] = { -10.0f, 50.0f, -380.0f, 1.0f };
	// Get the light position in eye space
	M3DVector4f	vLightTransformed, vLightTransformed1;
	M3DMatrix44f mCamera;
	modelViewMatrix.GetMatrix(mCamera);
	m3dTransformVector4(vLightTransformed, vLightPos, mCamera);

	m3dTransformVector4(vLightTransformed1, vLightPos, mCamera);
	// Draw the light source
	modelViewMatrix.PushMatrix();
	modelViewMatrix.Translatev(vLightPos);
	shaderManager.UseStockShader(GLT_SHADER_FLAT,
		transformPipeline.GetModelViewProjectionMatrix(),
		vWhite);
	sphereBatch.Draw();
	modelViewMatrix.PopMatrix();


	
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);

	for (int i = 0; i < 24; i++) {
		for (int j = 0; j < 4; j++)
		{
			modelViewMatrix.PushMatrix();
			modelViewMatrix.MultMatrix(cyl[i][j]);
			modelViewMatrix.Rotate(-90.0f, 1.0f, 0.0f, 0.0f);
			shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
				modelViewMatrix.GetMatrix(),
				transformPipeline.GetProjectionMatrix(),
				vLightTransformed,
				vWhite,
				0);

			diskBatch.Draw();

			modelViewMatrix.PopMatrix();
		}
	}

	for (int i = 0; i < 24; i++) {
		for (int j = 0; j < 4; j++)
		{
			modelViewMatrix.PushMatrix();
			modelViewMatrix.MultMatrix(cyl[i][j]);
			modelViewMatrix.Rotate(90.0f, 1.0f, 0.0f, 0.0f);
			
			shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
				modelViewMatrix.GetMatrix(),
				transformPipeline.GetProjectionMatrix(),
				vLightTransformed,
				vWhite,
				0);
			cylBatch.Draw();
		
			

			modelViewMatrix.PopMatrix();
		}
	}

	glBindTexture(GL_TEXTURE_2D, uiTextures[5]);

	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 12; j++)
		{
			modelViewMatrix.PushMatrix();
			modelViewMatrix.MultMatrix(cu[i][j]);
			/*shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
				modelViewMatrix.GetMatrix(),
				transformPipeline.GetProjectionMatrix(),
				vLightTransformed1,
				vWhite,
				0);
				*/

			shaderManager.UseStockShader(GLT_SHADER_TEXTURE_REPLACE,
				transformPipeline.GetModelViewProjectionMatrix(), 0);



			if (m[i][j]==1)
			cubeBatch.Draw();

			modelViewMatrix.PopMatrix();
		}
	}


}

void WorldOrder1(GLfloat yRot)	
	{
	static GLfloat vWhite[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	static GLfloat vLightPos[] = { 0.0f, 3.0f, 0.0f, 1.0f };
	
	// Get the light position in eye space
	M3DVector4f	vLightTransformed;
	M3DMatrix44f mCamera;
	modelViewMatrix.GetMatrix(mCamera);
	m3dTransformVector4(vLightTransformed, vLightPos, mCamera);
	
	// Draw the light source
	modelViewMatrix.PushMatrix();
	modelViewMatrix.Translatev(vLightPos);
	shaderManager.UseStockShader(GLT_SHADER_FLAT, 
								 transformPipeline.GetModelViewProjectionMatrix(),
								 vWhite);
	sphereBatch.Draw();


	modelViewMatrix.PopMatrix();
    
	
	
	modelViewMatrix.Translate(0.0f, 0.6f, -2.5f);
	modelViewMatrix.PushMatrix();	// Saves the translated origin
	modelViewMatrix.Rotate(yRot, 0.0f, 1.0f, 0.0f);
	
	// Draw stuff relative to the camera
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
								 modelViewMatrix.GetMatrix(),
								 transformPipeline.GetProjectionMatrix(),
								 vLightTransformed, 
								 vWhite,
								 0);
	
	torusBatch.Draw();
	modelViewMatrix.PopMatrix(); // Erased the rotate
	
	
	modelViewMatrix.Rotate(yRot * -1.0f, 0.0f, 1.0f, 0.0f);
	modelViewMatrix.Translate(2.0f, 0.0f, 0.0f);
	
	glBindTexture(GL_TEXTURE_2D, uiTextures[2]);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
								 modelViewMatrix.GetMatrix(),
								 transformPipeline.GetProjectionMatrix(),
								 vLightTransformed, 
								 vWhite,
								 0);
	sphereBatch.Draw();
	

	glBindTexture(GL_TEXTURE_2D, uiTextures[2]);
	for (int i = 0; i < NUM_SPHERES; i++) {
		modelViewMatrix.PushMatrix();
		modelViewMatrix.MultMatrix(spheres[i]);
		//spheres[i].SetOrigin(0.0f, 0.2f, -2.5f);
		//modelViewMatrix.Translate(r, 0.0f, 0.0f);
		shaderManager.UseStockShader(GLT_SHADER_TEXTURE_POINT_LIGHT_DIFF,
			modelViewMatrix.GetMatrix(),
			transformPipeline.GetProjectionMatrix(),
			vLightTransformed,
			vWhite,
			0);
		sphereBatch.Draw();
		modelViewMatrix.PopMatrix();
	}
	}
	
	
bool LoadTGATexture(const char *szFileName, GLenum minFilter, GLenum magFilter, GLenum wrapMode)
	{
	GLbyte *pBits;
	int nWidth, nHeight, nComponents;
	GLenum eFormat;
	

	// Read the texture bits
	pBits = gltReadTGABits(szFileName, &nWidth, &nHeight, &nComponents, &eFormat);
	if(pBits == NULL) 
		return false;
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapMode);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapMode);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
		
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGB, nWidth, nHeight, 0,
				 eFormat, GL_UNSIGNED_BYTE, pBits);
	
    free(pBits);

    if(minFilter == GL_LINEAR_MIPMAP_LINEAR || 
       minFilter == GL_LINEAR_MIPMAP_NEAREST ||
       minFilter == GL_NEAREST_MIPMAP_LINEAR ||
       minFilter == GL_NEAREST_MIPMAP_NEAREST)
        glGenerateMipmap(GL_TEXTURE_2D);
            
	return true;
	}

        
//////////////////////////////////////////////////////////////////
// This function does any needed initialization on the rendering
// context. 
void SetupRC()
{
	// Make sure OpenGL entry points are set
	glewInit();

	// Initialze Shader Manager
	shaderManager.InitializeStockShaders();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glClearColor(0.196078f, 0.6f, 0.8f, 0.5f);

	// This makes a torus
	gltMakeTorus(torusBatch, 0.8f, 0.3f, 40, 20);

	// This makes a sphere
	gltMakeSphere(sphereBatch, 0.5f, 26, 13);
	
	gltMakeCylinder(cylBatch, 0.5f, 0.5f, 3.0f, 20, 10);
	gltMakeDisk(diskBatch, 0.0f, 0.5f, 20, 10);
	gltMakeCube(cubeBatch, 2.0f);


	// Make the solid ground
	GLfloat texSize = 10.0f;
	GLfloat texSize1 = 1.0f;

	floorBatch.Begin(GL_TRIANGLE_FAN, 4, 1);
	floorBatch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floorBatch.Vertex3f(-60.0f, -0.41f, 70.0f);

	floorBatch.MultiTexCoord2f(0, texSize, 0.0f);
	floorBatch.Vertex3f(60.0f, -0.41f, 70.0f);

	floorBatch.MultiTexCoord2f(0, texSize, texSize);
	floorBatch.Vertex3f(60.0f, -0.41f, -70.0f);

	floorBatch.MultiTexCoord2f(0, 0.0f, texSize);
	floorBatch.Vertex3f(-60.0f, -0.41f, -70.0f);
	floorBatch.End();


	floorBatch1.Begin(GL_TRIANGLE_FAN, 4, 1);
	floorBatch1.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floorBatch1.Vertex3f(-2.5f, -0.41f, -70.0f);

	floorBatch1.MultiTexCoord2f(0, texSize1, 0.0f);
	floorBatch1.Vertex3f(2.5f, -0.41f, -70.0f);

	floorBatch1.MultiTexCoord2f(0, texSize1, texSize1);
	floorBatch1.Vertex3f(2.5f, -0.41f, -130.0f);

	floorBatch1.MultiTexCoord2f(0, 0.0f, texSize1);
	floorBatch1.Vertex3f(-2.5f, -0.41f, -130.0f);
	floorBatch1.End();

	floorBatch2.Begin(GL_TRIANGLE_FAN, 4, 1);
	floorBatch2.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floorBatch2.Vertex3f(-2.5f, -0.41f, -375.0f);

	floorBatch2.MultiTexCoord2f(0, texSize1, 0.0f);
	floorBatch2.Vertex3f(2.5f, -0.41f, -375.0f);

	floorBatch2.MultiTexCoord2f(0, texSize1, texSize1);
	floorBatch2.Vertex3f(2.5f, -0.41f, -420.0f);

	floorBatch2.MultiTexCoord2f(0, 0.0f, texSize1);
	floorBatch2.Vertex3f(-2.5f, -0.41f, -420.0f);
	floorBatch2.End();

	


	floorBatch3.Begin(GL_TRIANGLE_FAN, 4, 1);
	floorBatch3.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floorBatch3.Vertex3f(-60.0f, -0.41f, -420.0f);

	floorBatch3.MultiTexCoord2f(0, texSize1, 0.0f);
	floorBatch3.Vertex3f(60.0f, -0.41f, -420.0f);

	floorBatch3.MultiTexCoord2f(0, texSize1, texSize1);
	floorBatch3.Vertex3f(60.0f, -0.41f, -600.0f);

	floorBatch3.MultiTexCoord2f(0, 0.0f, texSize1);
	floorBatch3.Vertex3f(-60.0f, -0.41f, -600.0f);
	floorBatch3.End();

	/*
	//Make other grounds
	ceilingBatch.Begin(GL_TRIANGLE_FAN, 4, 1);
	ceilingBatch.MultiTexCoord2f(0.0f, 0.0f, 0.0f);
	ceilingBatch.Vertex3f(-20.0f, 7.0f, -70.0f);

	ceilingBatch.MultiTexCoord2f(0.0f, texSize, 0.0f);
	ceilingBatch.Vertex3f(20.0f, 7.0f, -70.0f);

	ceilingBatch.MultiTexCoord2f(0.0f, texSize, texSize);
	ceilingBatch.Vertex3f(20.0f, 7.0f, -100.0f);

	ceilingBatch.MultiTexCoord2f(0.0f, 0.0f, texSize);
	ceilingBatch.Vertex3f(-20.0f, 7.0f, -100.0f);
	ceilingBatch.End();

	leftWallBatch.Begin(GL_TRIANGLE_FAN, 4, 1);
	leftWallBatch.MultiTexCoord2f(0, 0.0f, 0.0f);
	leftWallBatch.Vertex3f(-20.0f, 0.0f, -70.0f);

	leftWallBatch.MultiTexCoord2f(0.0f, texSize,0.0f);
	leftWallBatch.Vertex3f(-20.0f, 7.0f, -70.0f);

	leftWallBatch.MultiTexCoord2f(0.0f, texSize, texSize);
	leftWallBatch.Vertex3f(-20.0f, 0.0f, -100.0f);

	leftWallBatch.MultiTexCoord2f(0.0f, 0.0f, texSize);
	leftWallBatch.Vertex3f(-20.0f, 7.0f, -100.0f);

	leftWallBatch.End();

	rightWallBatch.Begin(GL_TRIANGLE_FAN, 4, 1);
	rightWallBatch.MultiTexCoord2f(0.0f, 0.0f, 0.0f);
	rightWallBatch.Vertex3f(20.0f, 0.0f, -70.0f);

	rightWallBatch.MultiTexCoord2f(0.0f, texSize, 0.0f);
	rightWallBatch.Vertex3f(20.0f, 7.0f, -70.0f);

	rightWallBatch.MultiTexCoord2f(0.0f, texSize, texSize);
	rightWallBatch.Vertex3f(20.0f, 0.0f, -100.0f);

	rightWallBatch.MultiTexCoord2f(0.0f, 0.0f, texSize);
	rightWallBatch.Vertex3f(20.0f, 7.0f, -100.0f);

	rightWallBatch.End();
	*/
	// Make 5 texture objects
	glGenTextures(5, uiTextures);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[0]);
	LoadTGATexture("water.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);
	LoadTGATexture("stone.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[2]);
	LoadTGATexture("moonlike.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);


	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[3]);
	LoadTGATexture("sand.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[4]);
	LoadTGATexture("grass.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);


	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[5]);
	LoadTGATexture("wall.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);

	// Randomly place the spheres
	for (int i = 0; i < NUM_SPHERES; i++) {
		GLfloat x = ((GLfloat)((rand() % 800) - 400) * 0.1f);
		GLfloat z = ((GLfloat)((rand() % 800) - 400) * 0.1f);
		spheres[i].SetOrigin(x, 0.0f, z);
	}

		for (int i = 0; i < 24; i++) {
			for (int j = 0; j < 4; j++)
				cyl[i][j].SetOrigin(-5.0*(j-2), -0.41f, -140.0 - 10.0*i);
		}

		for (int i = 0; i < 12; i++)
		{
			for (int j = 0; j < 12; j++)
				cu[i][j].SetOrigin(-22.0 + (4.0*j), 1.59f, -430 - 4.0*i);
		}
	
}

////////////////////////////////////////////////////////////////////////
// Do shutdown for the rendering context
void ShutdownRC(void)
    {
	glDeleteTextures(6, uiTextures);
    }



        
// Called to draw scene
void RenderScene(void)
	{
	static CStopWatch	rotTimer;
	float yRot = rotTimer.GetElapsedSeconds() * 60.0f;
	
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	modelViewMatrix.PushMatrix();	
	M3DMatrix44f mCamera;
	cameraFrame.GetCameraMatrix(mCamera);
	modelViewMatrix.MultMatrix(mCamera);
	
	/*
	// Draw the world upside down
	modelViewMatrix.PushMatrix();
	modelViewMatrix.Scale(1.0f, -1.0f, 1.0f); // Flips the Y Axis
	modelViewMatrix.Translate(0.0f, 0.8f, 0.0f); // Scootch the world down a bit...
	glFrontFace(GL_CW);
	WorldOrder(yRot);
	glFrontFace(GL_CCW);
	modelViewMatrix.PopMatrix();
	*/
	static GLfloat vFloorColor[] = { 1.0f, 1.0f, 1.0f, 0.75f };


	glBindTexture(GL_TEXTURE_2D, uiTextures[4]);

	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_REPLACE,
		transformPipeline.GetModelViewProjectionMatrix(), 0);

	floorBatch1.Draw();
	floorBatch2.Draw();

	glBindTexture(GL_TEXTURE_2D, uiTextures[3]);

	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_REPLACE,
		transformPipeline.GetModelViewProjectionMatrix(), 0);

	floorBatch3.Draw();

	// Draw the solid ground
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, uiTextures[0]);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_MODULATE,
								 transformPipeline.GetModelViewProjectionMatrix(),
								 vFloorColor,
								 0);
	
	floorBatch.Draw();
	
	glDisable(GL_BLEND);
	
	WorldOrder2();
	WorldOrder1(yRot);

	modelViewMatrix.PopMatrix();
	
        
    // Do the buffer Swap
    glutSwapBuffers();
        
    // Do it again
    glutPostRedisplay();
    }



// Respond to arrow keys by moving the camera frame of reference
void SpecialKeys(int key, int x, int y)
    {
	float linear = 0.3f;
	float angular = float(m3dDegToRad(5.0f));
	
	if(key == GLUT_KEY_UP)
		cameraFrame.MoveForward(linear);
	
	if(key == GLUT_KEY_DOWN)
		cameraFrame.MoveForward(-linear);
	
	if(key == GLUT_KEY_LEFT)
		cameraFrame.RotateWorld(angular, 0.0f, 1.0f, 0.0f);
	
	if(key == GLUT_KEY_RIGHT)
		cameraFrame.RotateWorld(-angular, 0.0f, 1.0f, 0.0f);	
    }


void ChangeSize(int nWidth, int nHeight)
    {
	glViewport(0, 0, nWidth, nHeight);
	transformPipeline.SetMatrixStacks(modelViewMatrix, projectionMatrix);
	
	viewFrustum.SetPerspective(45.0f, float(nWidth)/float(nHeight), 0.01f, 120.0f);
	projectionMatrix.LoadMatrix(viewFrustum.GetProjectionMatrix());
	modelViewMatrix.LoadIdentity();
	}

int main(int argc, char* argv[])
    {
	gltSetWorkingDirectory(argv[0]);
		
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1024,768);
  
    glutCreateWindow("Anurag Misra");
 
    glutReshapeFunc(ChangeSize);
    glutDisplayFunc(RenderScene);
    glutSpecialFunc(SpecialKeys);
	 
    SetupRC();
    glutMainLoop();    
    ShutdownRC();
    return 0;
    }
