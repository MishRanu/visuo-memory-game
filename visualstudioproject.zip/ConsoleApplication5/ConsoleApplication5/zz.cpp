//Anurag Misra 12144
//Made as a part of Computer Graphics Course
#define _CRT_SECURE_NO_WARNINGS
#include <GLTools.h>
#include <GLShaderManager.h>
#include <GLFrustum.h>
#include <GLBatch.h>
#include <GLMatrixStack.h>
#include <GLGeometryTransform.h>
#include <StopWatch.h>
#include <math.h>
#include <stdio.h>

#ifdef __APPLE__
#include <glut/glut.h>
#else
#include <GL/glut.h>
#endif


float ang = 0.0;
float ang2 = 0.0;
float tmp_ang = 0.0;
float f = -5.0;
float f2 = 0.0;
float f3 = 0.0;
int r = 1;
int maxx;
int maxz;
int tx;
int ty;

int m[12][12] = { { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 }, { 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
{ 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1 }, { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1 }, { 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1 },
{ 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1 }, { 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1 }, { 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1 }, { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

GLuint	uiTextures[5];


GLFrame             viewFrame;
GLFrustum           viewFrustum;
GLTriangleBatch     sphereBatch;
GLMatrixStack       modelViewMatrix;
GLMatrixStack       projectionMatrix;
GLGeometryTransform transformPipeline;
GLShaderManager     shaderManager;
GLBatch floBatch;
GLBatch W1Batch;
GLBatch W2Batch;
GLBatch W3Batch;
GLBatch W4Batch;
GLBatch W5Batch;
GLFrame	cameraFrame;
/*
void flo(float x1, float x2, float y1, float z1, float z2){

	GLfloat texSize = 10.0f;

	static GLfloat vFloorColor[] = { 1.0f, 1.0f, 1.0f, 0.75f };
	floBatch.Begin(GL_TRIANGLE_FAN, 4, 1);

	floBatch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floBatch.Vertex3f(x2, y1, z1);

	floBatch.MultiTexCoord2f(0, texSize, 0.0f);
	floBatch.Vertex3f(x1, y1, z1);

	floBatch.MultiTexCoord2f(0, texSize, texSize);
	floBatch.Vertex3f(x1, y1, z2);

	floBatch.MultiTexCoord2f(0, 0.0f, texSize);
	floBatch.Vertex3f(x2, y1, z2);
	floBatch.End();


	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, uiTextures[0]);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_MODULATE,
		transformPipeline.GetModelViewProjectionMatrix(),
		vFloorColor,
		0);

	floBatch.Draw();
	

	glDisable(GL_BLEND);



}

void cu(float x1, float x2, float y1, float y2, float z1, float z2){


	

	GLfloat texSize = 10.0f;
	static GLfloat vFloorColor[] = { 1.0f, 1.0f, 1.0f, 0.75f };


	W1Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W1Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W1Batch.Vertex3f(x1, y1, z1);

	W1Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W1Batch.Vertex3f(x2, y1, z1);

	W1Batch.MultiTexCoord2f(0, texSize, texSize);
	W1Batch.Vertex3f(x2, y2, z1);

	W1Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W1Batch.Vertex3f(x1, y2, z1);
	W1Batch.End();


	W2Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W2Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W2Batch.Vertex3f(x1, y1, z2);

	W2Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W2Batch.Vertex3f(x2, y1, z2);

	W2Batch.MultiTexCoord2f(0, texSize, texSize);
	W2Batch.Vertex3f(x2, y2, z2);

	W2Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W2Batch.Vertex3f(x1, y2, z2);
	W2Batch.End();


	W3Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W3Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W3Batch.Vertex3f(x1, y2, z1);

	W3Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W3Batch.Vertex3f(x2, y2, z1);

	W3Batch.MultiTexCoord2f(0, texSize, texSize);
	W3Batch.Vertex3f(x2, y2, z2);

	W3Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W3Batch.Vertex3f(x1, y2, z2);
	W3Batch.End();

	W4Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W4Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W4Batch.Vertex3f(x1, y1, z1);

	W4Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W4Batch.Vertex3f(x1, y2, z1);

	W4Batch.MultiTexCoord2f(0, texSize, texSize);
	W4Batch.Vertex3f(x1, y2, z2);

	W4Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W4Batch.Vertex3f(x1, y1, z2);
	W4Batch.End();

	W5Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W5Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W5Batch.Vertex3f(x2, y1, z1);

	W5Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W5Batch.Vertex3f(x2, y2, z1);

	W5Batch.MultiTexCoord2f(0, texSize, texSize);
	W5Batch.Vertex3f(x2, y2, z2);

	W5Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W5Batch.Vertex3f(x2, y1, z2);
	W5Batch.End();



	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_MODULATE,
		transformPipeline.GetModelViewProjectionMatrix(),
		vFloorColor,
		0);

	W1Batch.Draw();
	W2Batch.Draw();
	W3Batch.Draw();
	W4Batch.Draw();
	W5Batch.Draw();


	glDisable(GL_BLEND);

	
}

*/

void flo(float x1, float x2, float y1, float z1, float z2){
	glBegin(GL_QUADS);
	glColor3f(0.62, 0.62, 0.37);
	glVertex3f(x2, y1, z1);
	glVertex3f(x1, y1, z1);
	glVertex3f(x1, y1, z2);
	glVertex3f(x2, y1, z2);

	glEnd();
}
void cu(float x1, float x2, float y1, float y2, float z1, float z2){
	glBegin(GL_QUADS);

	glColor3f(0.32, 0.32, 0.49);
	glVertex3f(x1, y1, z1);
	glVertex3f(x2, y1, z1);
	glVertex3f(x2, y2, z1);
	glVertex3f(x1, y2, z1);

	glColor3f(0.14, 0.14, 0.56);
	glVertex3f(x1, y1, z2);
	glVertex3f(x2, y1, z2);
	glVertex3f(x2, y2, z2);
	glVertex3f(x1, y2, z2);

	glColor3f(0.14, 0.14, 0.56);
	glVertex3f(x1, y2, z1);
	glVertex3f(x2, y2, z1);
	glVertex3f(x2, y2, z2);
	glVertex3f(x1, y2, z2);

	glColor3f(0.184314, 0.309804, 0.309804);
	glVertex3f(x1, y1, z1);
	glVertex3f(x1, y2, z1);
	glVertex3f(x1, y2, z2);
	glVertex3f(x1, y1, z2);

	glColor3f(0.32, 0.49, 0.49);
	glVertex3f(x2, y1, z1);
	glVertex3f(x2, y2, z1);

	glVertex3f(x2, y2, z2);
	glVertex3f(x2, y1, z2);

	glEnd();
}
void WorldOrder()
{
	static GLfloat vWhite[] = { 0.1f, 0.1f, 0.1f, 0.1f };
	static GLfloat vLightPos[] = { 0.0f, 1.0f, 0.0f, 1.0f };

	// Get the light position in eye space
	M3DVector4f	vLightTransformed;
	M3DMatrix44f mCamera;
	modelViewMatrix.GetMatrix(mCamera);
	m3dTransformVector4(vLightTransformed, vLightPos, mCamera); 

	// Draw the light source
	modelViewMatrix.PushMatrix();
	modelViewMatrix.Translatev(vLightPos);
	shaderManager.UseStockShader(GLT_SHADER_FLAT,
		transformPipeline.GetModelViewProjectionMatrix(),
		vWhite);
	sphereBatch.Draw();
	modelViewMatrix.PopMatrix();



	
}


bool LoadTGATexture(const char *szFileName, GLenum minFilter, GLenum magFilter, GLenum wrapMode)
{
	GLbyte *pBits;
	int nWidth, nHeight, nComponents;
	GLenum eFormat;

	// Read the texture bits
	pBits = gltReadTGABits(szFileName, &nWidth, &nHeight, &nComponents, &eFormat);
	if (pBits == NULL)
		return false;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapMode);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapMode);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGB, nWidth, nHeight, 0,
		eFormat, GL_UNSIGNED_BYTE, pBits);

	free(pBits);

	if (minFilter == GL_LINEAR_MIPMAP_LINEAR ||
		minFilter == GL_LINEAR_MIPMAP_NEAREST ||
		minFilter == GL_NEAREST_MIPMAP_LINEAR ||
		minFilter == GL_NEAREST_MIPMAP_NEAREST)
		glGenerateMipmap(GL_TEXTURE_2D);

	return true;
}


void SetupRC()
{
	// Make sure OpenGL entry points are set
	glewInit();

	// Initialze Shader Manager
	shaderManager.InitializeStockShaders();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glClearColor(0.196078f, 0.6f, 0.8f, 0.5f);

	gltMakeSphere(sphereBatch, 0.1f, 26, 13);
	// Make 5 texture objects
	glGenTextures(5, uiTextures);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[0]);
	LoadTGATexture("water.tga", GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR, GL_REPEAT);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);
	LoadTGATexture("stone.tga", GL_LINEAR_MIPMAP_LINEAR,
		GL_LINEAR, GL_CLAMP_TO_EDGE);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[2]);
	LoadTGATexture("moonlike.tga", GL_LINEAR_MIPMAP_LINEAR,
		GL_LINEAR, GL_CLAMP_TO_EDGE);


	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[3]);
	LoadTGATexture("ceiling.tga", GL_LINEAR_MIPMAP_LINEAR,
		GL_LINEAR, GL_CLAMP_TO_EDGE);

	// Load Texture
	glBindTexture(GL_TEXTURE_2D, uiTextures[4]);
	LoadTGATexture("grass.tga", GL_LINEAR_MIPMAP_LINEAR,
		GL_LINEAR, GL_CLAMP_TO_EDGE);


	
}


////////////////////////////////////////////////////////////////////////
// Do shutdown for the rendering context
void ShutdownRC(void)
{
	glDeleteTextures(5, uiTextures);
}




// Called to draw scene
void RenderScene()
{
	static CStopWatch rotTimer;
	float yRot = rotTimer.GetElapsedSeconds() * 60.0f;


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	modelViewMatrix.PushMatrix();
	M3DMatrix44f mCamera;
	cameraFrame.GetCameraMatrix(mCamera);
	modelViewMatrix.MultMatrix(mCamera);

	/*

	modelViewMatrix.Rotate(ang, 0.0, 1.0, 0.0);
	modelViewMatrix.Rotate(ang2, 1.0, 0.0, 0.0);
	modelViewMatrix.Translate(f2, f3, f);
	*/

	WorldOrder();

	int i, j;
	for (i = 0; i < maxx; i++){
		for (j = 0; j < maxz; j++){
			if (m[j][i] == 1) cu(4*i, 4*(i + 1), -2.0, 2.0, -4.0*j, -4.0*(j + 1));
			else flo(4.0*i, 4.0*(i + 1), -2.0, 4.0*j, -4.0*(j + 1));
		}
	 }

	modelViewMatrix.PopMatrix();


	// Do the buffer Swap
	glutSwapBuffers();

	// Do it again
	
}


// Respond to arrow keys by moving the camera frame of reference
void SpecialKeys(int key, int x, int y)
{
	float linear = 0.3f;
	float angular = float(m3dDegToRad(5.0f));


	if (key == GLUT_KEY_UP)
		cameraFrame.MoveForward(linear);

	if (key == GLUT_KEY_DOWN)
		cameraFrame.MoveForward(-linear);

	if (key == GLUT_KEY_LEFT)
		cameraFrame.RotateWorld(angular, 0.0f, 1.0f, 0.0f);

	if (key == GLUT_KEY_RIGHT)
		cameraFrame.RotateWorld(-angular, 0.0f, 1.0f, 0.0f);
}


void ChangeSize(int nWidth, int nHeight)
{
	glViewport(0, 0, nWidth, nHeight);
	transformPipeline.SetMatrixStacks(modelViewMatrix, projectionMatrix);

	viewFrustum.SetPerspective(30.0f, float(nWidth) / float(nHeight), 0.1f, 20.0f);
	projectionMatrix.LoadMatrix(viewFrustum.GetProjectionMatrix());
	modelViewMatrix.LoadIdentity();
}


int main(int argc, char* argv[])
{ 
	
	maxx = 12;
	maxz = 12;
	
	f2 = -0.6;
	f = 0.6;
	

	gltSetWorkingDirectory(argv[0]);


	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1024, 768);

	glutCreateWindow("Anurag Misra");

	glutReshapeFunc(ChangeSize);
	glutDisplayFunc(RenderScene);
	glutSpecialFunc(SpecialKeys);

	SetupRC();
	glutMainLoop();
	ShutdownRC();
	return 0;
}
