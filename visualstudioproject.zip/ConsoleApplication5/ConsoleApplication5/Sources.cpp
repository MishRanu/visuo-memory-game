
#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int **m;
int maxx;
int maxy;

void print_mas(){
	int i, j;
	for (j = 0; j < maxy; j++){
		for (i = 0; i < maxx; i++){
			if (m[j][i] == 1) printf("%c ", 127);
			else if (m[j][i] == 0) printf("  ");
			else if (m[j][i] == 2) printf("*");
		}
		printf("\n");
	}
	printf("\n");
}
void call(int, int, int, int);
void gen(int x, int y, int ox, int oy){
	if (x + 1 < maxx && y + 1 < maxy && x > 0 && y  > 0){
		if (m[y - 1][x] != 0 || (x == ox && y - 1 == oy)){
			if (m[y][x - 1] != 0 || (x - 1 == ox && y == oy)){
				if (m[y][x + 1] != 0 || (x + 1 == ox && y == oy)){
					if (m[y + 1][x] != 0 || (x == ox && y + 1 == oy)){
						m[y][x] = 0;
						system("clear");
						print_mas();
						system("sleep 0.2");
						call(x, y, ox, oy);
					}
				}
			}
		}
	}
}
void call(int x, int y, int ox, int oy){
	srand(time(NULL));
	int i = rand() % 10;
	if (i == 0){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
	}
	else if (i == 1){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
	}
	else if (i == 2){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
	}
	else if (i == 3){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
	}
	else if (i == 4){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
	}
	else if (i == 5){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
	}
	else if (i == 6){
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
	}
	else if (i == 7){
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
	}
	else if (i == 8){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
	}
	else if (i == 9){
		if (x != ox || y + 1 != oy) gen(x, y + 1, x, y);
		if (x - 1 != ox || y != oy) gen(x - 1, y, x, y);
		if (x != ox || y - 1 != oy) gen(x, y - 1, x, y);
		if (x + 1 != ox || y != oy) gen(x + 1, y, x, y);
	}
}
void print_mas2(){
	int i, j;
	FILE *f = fopen("ab.txt", "w");
	if (f == NULL) return;
	for (j = 0; j < maxy; j++){
		for (i = 0; i < maxx; i++){
			if (m[j][i] == 1) fputc('1', f);
			else if (m[j][i] == 0) fputc('0', f);
		}
		fputc('\n', f);
	}
}
void main(int argc, char **argv){
	if (argc < 3){
		printf("\n usage :\n\n ./gen length height\n");
		return;
	}
	maxx = atoi(argv[1]);
	maxy = atoi(argv[2]);
	m = (int **)malloc(sizeof(int *)* maxy);
	int i;
	int j;
	for (i = 0; i < maxy; i++){
		m[i] = (int *)malloc(sizeof(int)* maxx);
		for (j = 0; j < maxx; j++){
			m[i][j] = 1;
		}
	}
	system("clear");
	srand(time(NULL));
	int rx = rand() % maxx;
	srand(time(NULL));
	int ry = rand() % maxy;
	gen(rx, ry, maxx, maxy);
	print_mas();
	print_mas2();
}
