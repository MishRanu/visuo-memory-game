//Anurag Misra 12144
//Made as a part of Computer Graphics Course
#define _CRT_SECURE_NO_WARNINGS
#include <GLTools.h>
#include <GLShaderManager.h>
#include <GLFrustum.h>
#include <GLBatch.h>
#include <GLMatrixStack.h>
#include <GLGeometryTransform.h>
#include <StopWatch.h>
#include <math.h>
#include <stdio.h>

#ifdef __APPLE__
#include <glut/glut.h>
#else
#include <GL/glut.h>
#endif



float ang = 0.0;
float ang2 = 0.0;
float tmp_ang = 0.0;
float f = -5.0;
float f2 = 0.0;
float f3 = 0.0;
int r = 1;
int maxx;
int maxz;
int tx;
int ty;
int **m;
GLuint	uiTextures[5];



GLFrame             viewFrame;
GLFrustum           viewFrustum;
GLTriangleBatch     sphereBatch;
GLMatrixStack       modelViewMatrix;
GLMatrixStack       projectionMatrix;
GLGeometryTransform transformPipeline;
GLShaderManager     shaderManager;
GLBatch floBatch;
GLBatch W1Batch;
GLBatch W2Batch;
GLBatch W3Batch;
GLBatch W4Batch;
GLBatch W5Batch;
GLFrame	cameraFrame;

void flo(float x1, float x2, float y1, float z1, float z2){
	GLfloat texSize = 10.0f;

	static GLfloat vFloorColor[] = { 1.0f, 1.0f, 1.0f, 0.75f };
	floBatch.Begin(GL_TRIANGLE_FAN, 4, 1);

	floBatch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	floBatch.Vertex3f(x2, y1, z1);

	floBatch.MultiTexCoord2f(0, texSize, 0.0f);
	floBatch.Vertex3f(x1, y1, z1);

	floBatch.MultiTexCoord2f(0, texSize, texSize);
	floBatch.Vertex3f(x1, y1, z2);

	floBatch.MultiTexCoord2f(0, 0.0f, texSize);
	floBatch.Vertex3f(x2, y1, z2);
	floBatch.End();


	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, uiTextures[0]);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_MODULATE,
		transformPipeline.GetModelViewProjectionMatrix(),
		vFloorColor,
		0);

	floBatch.Draw();


	glDisable(GL_BLEND);

}

void cu(float x1, float x2, float y1, float y2, float z1, float z2){


	GLfloat texSize = 10.0f;
	static GLfloat vFloorColor[] = { 1.0f, 1.0f, 1.0f, 0.75f };


	W1Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W1Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W1Batch.Vertex3f(x1, y1, z1);

	W1Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W1Batch.Vertex3f(x2, y1, z1);

	W1Batch.MultiTexCoord2f(0, texSize, texSize);
	W1Batch.Vertex3f(x2, y2, z1);

	W1Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W1Batch.Vertex3f(x1, y2, z1);
	W1Batch.End();


	W2Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W2Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W2Batch.Vertex3f(x1, y1, z2);

	W2Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W2Batch.Vertex3f(x2, y1, z2);

	W2Batch.MultiTexCoord2f(0, texSize, texSize);
	W2Batch.Vertex3f(x2, y2, z2);

	W2Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W2Batch.Vertex3f(x1, y2, z2);
	W2Batch.End();


	W3Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W3Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W3Batch.Vertex3f(x1, y2, z1);

	W3Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W3Batch.Vertex3f(x2, y2, z1);

	W3Batch.MultiTexCoord2f(0, texSize, texSize);
	W3Batch.Vertex3f(x2, y2, z2);

	W3Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W3Batch.Vertex3f(x1, y2, z2);
	W3Batch.End();

	W4Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W4Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W4Batch.Vertex3f(x1, y1, z1);

	W4Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W4Batch.Vertex3f(x1, y2, z1);

	W4Batch.MultiTexCoord2f(0, texSize, texSize);
	W4Batch.Vertex3f(x1, y2, z2);

	W4Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W4Batch.Vertex3f(x1, y1, z2);
	W4Batch.End();

	W5Batch.Begin(GL_TRIANGLE_FAN, 4, 1);

	W5Batch.MultiTexCoord2f(0.0, 0.0f, 0.0f);
	W5Batch.Vertex3f(x2, y1, z1);

	W5Batch.MultiTexCoord2f(0, texSize, 0.0f);
	W5Batch.Vertex3f(x2, y2, z1);

	W5Batch.MultiTexCoord2f(0, texSize, texSize);
	W5Batch.Vertex3f(x2, y2, z2);

	W5Batch.MultiTexCoord2f(0, 0.0f, texSize);
	W5Batch.Vertex3f(x2, y1, z2);
	W5Batch.End();



	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, uiTextures[1]);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	shaderManager.UseStockShader(GLT_SHADER_TEXTURE_MODULATE,
		transformPipeline.GetModelViewProjectionMatrix(),
		vFloorColor,
		0);

	W1Batch.Draw();
	W2Batch.Draw();
	W3Batch.Draw();
	W4Batch.Draw();
	W5Batch.Draw();


	glDisable(GL_BLEND);


}

void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(ang, 0.0, 1.0, 0.0);
	glRotatef(ang2, 1.0, 0.0, 0.0);
	
	glTranslatef(f2, f3, f);
	int i, j;
	for (i = 0; i < maxx; i++){
		for (j = 0; j < maxz; j++){
			if (m[j][i] == 1) cu(0.4*i, 0.4*(i + 1), -0.2, 0.2, -0.4*j, -0.4*(j + 1));
			else flo(0.4*i, 0.4*(i + 1), -0.2, -0.4*j, -0.4*(j + 1));
		}
	}
	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
	if (key == 27) exit(0);
	else if ((char)key == 'a' && r){
		ang -= 3.0;
		if (ang > 360.0) ang -= 360.0;
		if (ang < 0) ang += 360.0;
		glutPostRedisplay();
	}
	else if ((char)key == 'd' && r){
		ang += 3.0;
		if (ang < 0.0) ang += 360.0;
		if (ang > 360.0) ang -= 360.0;
		glutPostRedisplay();
	}
	else if ((char)key == 's' && r){
		int x = -1 * (int)((f2 + (0.1*sin(ang*(3.14 / 180)))) / 0.4);
		int z = (int)((f - (0.1*cos(ang*(3.14 / 180)))) / 0.4);
		if (x >= 0 && x < maxx && z >= 0 && z < maxz){
			if (m[z][x] == 0)f2 += 0.1*sin(ang*(3.14 / 180));
			if (m[z][x] == 0)f -= 0.1*cos(ang*(3.14 / 180));
		}
		else{
			f2 += 0.1*sin(ang*(3.14 / 180));
			f -= 0.1*cos(ang*(3.14 / 180));
		}
		glutPostRedisplay();
	}
	else if ((char)key == 'w' && r){
		int x = -1 * (int)((f2 - (0.1*sin(ang*(3.14 / 180)))) / 0.4);
		int z = (int)((f + (0.1*cos(ang*(3.14 / 180)))) / 0.4);
		if (x >= 0 && x < maxx && z >= 0 && z < maxz){
			if (m[z][x] == 0)f2 -= 0.1*sin(ang*(3.14 / 180));
			if (m[z][x] == 0)f += 0.1*cos(ang*(3.14 / 180));
		}
		else{
			f2 -= 0.1*sin(ang*(3.14 / 180));
			f += 0.1*cos(ang*(3.14 / 180));
		}
		glutPostRedisplay();
	}
	else if ((char)key == 'o'){
		if (r == 1){
			tmp_ang = ang;
			ang = 0.0;
			r = 0;
			f3 = -5.0;
			ang2 = 60.0;
			glutPostRedisplay();
		}
	}
	else if ((char)key == 'p'){
		if (r == 0){
			ang = tmp_ang;
			r = 1;
			f3 = 0.0;
			ang2 = 0.0;
			glutPostRedisplay();
		}
	}
}

void init()
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glEnable(GL_DEPTH_TEST);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
}
void Reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (double)w / (double)h, 0.1, 200.0);

}
int main(int argc, char** argv)
{
	char res[20];
	if (argc < 6){
		printf("\n usage :\n\n ./maze3D length height startx starty resolution\n");
		return 0;
	}
	maxx = atoi(argv[1]);
	maxz = atoi(argv[2]);
	f2 = -0.4*(2 * atoi(argv[3]) + 1) / 2;
	f = 0.4*(2 * atoi(argv[4]) + 1) / 2;
	m = (int **)malloc(sizeof(int *)* maxz);
	sprintf(res, "%s:16@60", argv[5]);
	FILE *f = fopen("ab.txt", "r");
	if (f == NULL) return 0;
	char c;
	int i = 0;
	int j = 0;
	m[i] = (int *)malloc(sizeof(int)* maxx);
	while ((c = fgetc(f)) != EOF){
		if (c == '\n'){
			i++;
			j = 0;
			m[i] = (int *)malloc(sizeof(int)* maxx);
		}
		else{
			if (c == '0') m[i][j] = 0;
			else m[i][j] = 1;
			j++;
		}
	}
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutGameModeString(res);

	glutEnterGameMode();
	glutReshapeFunc(Reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);

	init();
	glutMainLoop();


	return 0;
}
