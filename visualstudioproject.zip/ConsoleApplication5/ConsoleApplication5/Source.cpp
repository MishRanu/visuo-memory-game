/**
*Author :Tharindra Galahena
*Project:maze in 3D using c and openGL
*Date   :14/12/2011
*/
#define _CRT_SECURE_NO_WARNINGS 
#include <GLTools.h>
#include <GLShaderManager.h>
#include <GLFrustum.h>
#include <GLBatch.h>
#include <GLMatrixStack.h>
#include <GLGeometryTransform.h>
#include <StopWatch.h>

#include <math.h>
#include <stdio.h>

#ifdef __APPLE__
#include <glut/glut.h>
#else
#include <GL/glut.h>
#endif

GLShaderManager		shaderManager;			// Shader Manager
GLMatrixStack		modelViewMatrix;		// Modelview Matrix
GLMatrixStack		projectionMatrix;		// Projection Matrix
GLFrustum			viewFrustum;			// View Frustum
GLGeometryTransform	transformPipeline;		// Geometry Transform Pipeline
GLFrame				cameraFrame;			// Camera frame




float ang = 0.0;
float ang2 = 0.0;
float tmp_ang = 0.0;
float f = -5.0;
float f2 = 0.0;
float f3 = 0.0;
int r = 1;
int maxx;
int maxz;
int tx;
int ty;
int **m;

void flo(float x1, float x2, float y1, float z1, float z2){
	glBegin(GL_QUADS);

	glColor3f(0.0, 0.0, 0.2);
	glVertex3f(x2, y1, z1);
	glVertex3f(x1, y1, z1);
	glVertex3f(x1, y1, z2);
	glVertex3f(x2, y1, z2);

	glEnd();
}
void cu(float x1, float x2, float y1, float y2, float z1, float z2){
	glBegin(GL_QUADS);

	glColor3f(8.3, 0.2, 0.0);
	glVertex3f(x1, y1, z1);
	glVertex3f(x2, y1, z1);
	glColor3f(1.3, 7.2, 0.0);
	glVertex3f(x2, y2, z1);
	glVertex3f(x1, y2, z1);

	glColor3f(0.3, 9.2, 2.0);
	glVertex3f(x1, y1, z2);
	glVertex3f(x2, y1, z2);
	glColor3f(1.3, 0.2, 9.0);
	glVertex3f(x2, y2, z2);
	glVertex3f(x1, y2, z2);

	glColor3f(0.3, 7.2, 0.0);
	glVertex3f(x1, y2, z1);
	glVertex3f(x2, y2, z1);
	glColor3f(0.3, 0.2, 9.0);
	glVertex3f(x2, y2, z2);
	glVertex3f(x1, y2, z2);

	glColor3f(0.3, 0.2, 8.0);
	glVertex3f(x1, y1, z1);
	glVertex3f(x1, y2, z1);
	glColor3f(8.3, 0.2, 2.0);
	glVertex3f(x1, y2, z2);
	glVertex3f(x1, y1, z2);

	glColor3f(0.3, 0.2, 8.0);
	glVertex3f(x2, y1, z1);
	glVertex3f(x2, y2, z1);
	glColor3f(9.3, 0.2, 0.0);
	glVertex3f(x2, y2, z2);
	glVertex3f(x2, y1, z2);

	glEnd();
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	modelViewMatrix.PushMatrix();
	M3DMatrix44f mCamera;
	cameraFrame.GetCameraMatrix(mCamera);
	modelViewMatrix.MultMatrix(mCamera);

	glRotatef(ang, 0.0, 1.0, 0.0);
	glRotatef(ang2, 1.0, 0.0, 0.0);

	glTranslatef(f2, f3, f);
	int i, j;
	for (i = 0; i < maxx; i++){
		for (j = 0; j < maxz; j++){
			if (m[j][i] == 1) cu(0.4*i, 0.4*(i + 1), -0.2, 0.2, -0.4*j, -0.4*(j + 1));
			else flo(0.4*i, 0.4*(i + 1), -0.2, -0.4*j, -0.4*(j + 1));
		}
	}

	modelViewMatrix.PopMatrix();
	glutSwapBuffers();
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	if (key == 27) exit(0);
	else if ((char)key == 'a' && r){
		ang -= 1.0;
		if (ang > 360.0) ang -= 360.0;
		if (ang < 0) ang += 360.0;
		glutPostRedisplay();
	}
	else if ((char)key == 'd' && r){
		ang += 1.0;
		if (ang < 0.0) ang += 360.0;
		if (ang > 360.0) ang -= 360.0;
		glutPostRedisplay();
	}
	else if ((char)key == 's' && r){
		int x = -1 * (int)((f2 + (0.1*sin(ang*(3.14 / 180)))) / 0.4);
		int z = (int)((f - (0.1*cos(ang*(3.14 / 180)))) / 0.4);
		if (x >= 0 && x < maxx && z >= 0 && z < maxz){
			if (m[z][x] == 0)f2 += 0.1*sin(ang*(3.14 / 180));
			if (m[z][x] == 0)f -= 0.1*cos(ang*(3.14 / 180));
		}
		else{
			f2 += 0.1*sin(ang*(3.14 / 180));
			f -= 0.1*cos(ang*(3.14 / 180));
		}
		glutPostRedisplay();
	}
	else if ((char)key == 'w' && r){
		int x = -1 * (int)((f2 - (0.1*sin(ang*(3.14 / 180)))) / 0.4);
		int z = (int)((f + (0.1*cos(ang*(3.14 / 180)))) / 0.4);
		if (x >= 0 && x < maxx && z >= 0 && z < maxz){
			if (m[z][x] == 0)f2 -= 0.1*sin(ang*(3.14 / 180));
			if (m[z][x] == 0)f += 0.1*cos(ang*(3.14 / 180));
		}
		else{
			f2 -= 0.1*sin(ang*(3.14 / 180));
			f += 0.1*cos(ang*(3.14 / 180));
		}
		glutPostRedisplay();
	}
	else if ((char)key == 'o'){
		if (r == 1){
			tmp_ang = ang;
			ang = 0.0;
			r = 0;
			f3 = -5.0;
			ang2 = 60.0;
			glutPostRedisplay();
		}
	}
	else if ((char)key == 'p'){
		if (r == 0){
			ang = tmp_ang;
			r = 1;
			f3 = 0.0;
			ang2 = 0.0;
			glutPostRedisplay();
		}
	}
}

void init()
{

	// Make sure OpenGL entry points are set
	glewInit();

	// Initialze Shader Manager
	shaderManager.InitializeStockShaders();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glClearColor(0.0, 0.0, 0.0, 0.0);
	modelViewMatrix.PushMatrix();

	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
}

void Reshape(int nWidth, int nHeight)
{
glViewport(0, 0, nWidth, nHeight);
	transformPipeline.SetMatrixStacks(modelViewMatrix, projectionMatrix);

	viewFrustum.SetPerspective(45.0f, float(nWidth) / float(nHeight), 0.1f, 200.0f);
	projectionMatrix.LoadMatrix(viewFrustum.GetProjectionMatrix());
	modelViewMatrix.LoadIdentity();
}

int main(int argc, char** argv)
{
	char res[20];
	if (argc < 6){
		printf("\n usage :\n\n ./maze3D length height startx starty resolution\n");
		return 0;
	}
	maxx = atoi(argv[1]);
	maxz = atoi(argv[2]);
	f2 = -0.4*(2 * atoi(argv[3]) + 1) / 2;
	f = 0.4*(2 * atoi(argv[4]) + 1) / 2;
	m = (int **)malloc(sizeof(int *)* maxz);
	sprintf(res, "%s:16@60", argv[5]);
	FILE *f = fopen("ab.txt", "r");
	if (f == NULL) return 0;
	char c;
	int i = 0;
	int j = 0;
	m[i] = (int *)malloc(sizeof(int)* maxx);
	while ((c = fgetc(f)) != EOF){
		if (c == '\n'){
			i++;
			j = 0;
			m[i] = (int *)malloc(sizeof(int)* maxx);
		}
		else{
			if (c == '0') m[i][j] = 0;
			else m[i][j] = 1;
			j++;
		}
	}
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutGameModeString(res);

	glutEnterGameMode();
	glutReshapeFunc(Reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);

	init();
	glutMainLoop();
	return 0;
}
